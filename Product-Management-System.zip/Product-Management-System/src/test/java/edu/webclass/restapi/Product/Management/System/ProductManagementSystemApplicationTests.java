package edu.webclass.restapi.Product.Management.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
